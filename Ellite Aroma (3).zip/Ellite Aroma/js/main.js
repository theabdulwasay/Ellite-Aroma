document.addEventListener('DOMContentLoaded', () => {
    const productGrid = document.querySelector('.grid-3');
    // Determine category based on current page or specific data attribute
    // Default to handling both pages with specific selectors or URL check
    const isPerfumePage = window.location.pathname.includes('perfume.html');
    const isIttarPage = window.location.pathname.includes('ittar.html');

    let category = null;
    if (isPerfumePage) category = 'perfume';
    if (isIttarPage) category = 'ittar';

    if (category) {
        fetchProducts(category);
    }
});

async function fetchProducts(category) {
    const grid = document.querySelector('.grid-3');

    // Show loading state
    grid.innerHTML = '<p>Loading products...</p>';

    try {
        const response = await fetch(`http://localhost:3000/api/products/${category}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const products = await response.json();
        renderProducts(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        grid.innerHTML = '<p>Error loading products. Please make sure the backend server is running.</p>';
    }
}

function renderProducts(products) {
    const grid = document.querySelector('.grid-3');
    grid.innerHTML = ''; // Clear existing content

    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <div class="product-img">
                <img src="${product.image_url}" alt="${product.name}">
            </div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <span class="product-price">$${product.price}</span>
                <a href="#" class="btn-small">Add to Cart</a>
            </div>
        `;
        grid.appendChild(card);
    });
}
