CREATE DATABASE IF NOT EXISTS ellite_aroma;
USE ellite_aroma;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category ENUM('perfume', 'ittar') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    description TEXT
);

-- Seed Data using existing product information
INSERT INTO products (name, category, price, image_url, description) VALUES
-- Perfumes
('Midnight Orchid', 'perfume', 23630.00, 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80', 'A captivating scent for the modern soul.'),
('Golden Amber', 'perfume', 26410.00, 'golden_amber.png', 'Warm golden notes with a touch of luxury.'),
('Ocean Breeze', 'perfume', 20850.00, 'ocean_breeze.png', 'Fresh and invigorating like the sea.'),
('Rose Velvet', 'perfume', 24464.00, 'rose_velvet.png', 'Soft and romantic rose fragrance.'),
('Citrus Zest', 'perfume', 19460.00, 'https://images.unsplash.com/photo-1512777576244-b846ac3d816f?auto=format&fit=crop&w=800&q=80', 'Energetic and refreshing citrus blend.'),
('Royal Oud', 'perfume', 33360.00, 'https://images.unsplash.com/photo-1595475207225-428b62bda831?auto=format&fit=crop&w=800&q=80', 'A regal scent with deep woody notes.'),

-- Ittars
('Sandalwood Absolute', 'ittar', 12510.00, 'sandalwood_absolute.png', 'Pure, concentrated essence of sandalwood.'),
('Mysore Musk', 'ittar', 15290.00, 'mysore_musk.png', 'Rich and exotic musk from Mysore.'),
('Rose Damascus', 'ittar', 13900.00, 'rose_damascus.png', 'Traditional rose ittar with floral depth.'),
('Jasmine Night', 'ittar', 11120.00, 'mysore_musk.png', 'Intoxicating jasmine fragrance.'),
('Oud Afghano', 'ittar', 30580.00, 'mysore_musk.png', 'Premium, intense oud oil.'),
('Amber Gold', 'ittar', 16680.00, 'https://images.unsplash.com/photo-1563170351-be82bc888aa4?auto=format&fit=crop&w=800&q=80', 'Golden amber resin essence.');
