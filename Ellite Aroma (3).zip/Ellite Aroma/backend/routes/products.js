const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all products or filter by category
// Get all products
router.get('/', async (req, res) => {
    try {
        const query = 'SELECT * FROM products';
        const [rows] = await db.query(query);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
});

// Get products by category
router.get('/:category', async (req, res) => {
    try {
        const category = req.params.category;
        const query = 'SELECT * FROM products WHERE category = ?';
        const [rows] = await db.query(query, [category]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
});

module.exports = router;
