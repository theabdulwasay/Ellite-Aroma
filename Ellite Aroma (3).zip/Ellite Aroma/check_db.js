const db = require('./backend/config/db');

async function check() {
    try {
        const [rows] = await db.query('SELECT count(*) as count FROM products');
        console.log('SUCCESS: Products count:', rows[0].count);
        process.exit(0);
    } catch (err) {
        console.error('ERROR:', err.message);
        process.exit(1);
    }
}

check();
