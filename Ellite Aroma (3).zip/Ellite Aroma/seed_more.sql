USE ellite_aroma;

INSERT INTO products (name, category, price, image_url, description) VALUES
-- New Perfumes
('Sapphire Dreams', 'perfume', 92.00, 'https://images.unsplash.com/photo-1592914610354-fd354ea45e48?auto=format&fit=crop&w=800&q=80', 'A mysterious blue fragrance with cool aquatic notes.'),
('Vanilla Woods', 'perfume', 82.00, 'https://images.unsplash.com/photo-1622354805726-259837a726be?auto=format&fit=crop&w=800&q=80', 'Rich vanilla blended with warm cedarwood.'),
('Spiced Leather', 'perfume', 105.00, 'https://images.unsplash.com/photo-1557170334-a9632e77c6e4?auto=format&fit=crop&w=800&q=80', 'A bold masculine scent with leather and spice notes.'),

-- New Ittars
('White Oudh', 'ittar', 65.00, 'https://images.unsplash.com/photo-1595180635034-7505333f005d?auto=format&fit=crop&w=800&q=80', 'A soft, clean, and mystical oudh fragrance.'),
('Bakhoor Intense', 'ittar', 50.00, 'https://images.unsplash.com/photo-1615147343419-79de09e20ab0?auto=format&fit=crop&w=800&q=80', 'Smoky and sweet traditional bakhoor essence.'),
('Shamama Tul Amber', 'ittar', 75.00, 'https://images.unsplash.com/photo-1605330365063-ca02c8427f30?auto=format&fit=crop&w=800&q=80', 'A complex blend of herbs, spices, and amber.');
